package com.github.p4535992.util.log;

import java.io.IOException;

/**
 * Created by 4535992 on 05/11/2015.
 */
public class Test_SystemLog {

    public static void main(String[] args) throws IOException {
        SystemLog log = new SystemLog();
        System.out.println("Test 45");
        System.err.println("Test 42");
        log.close();
        SystemLog.setIsPRINT(true);
        log = new SystemLog("aaaaaa","txt");
        System.out.println("Test 45");
        System.err.println("Test 42");

    }
}
