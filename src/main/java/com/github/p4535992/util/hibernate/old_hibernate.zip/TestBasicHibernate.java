/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package util.hibernate;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
/**
 *
 * @author esd91martent
 */
public class TestBasicHibernate<T> {   
    
   private static Class cl;
   private String clName;
    
    public TestBasicHibernate(){
        java.lang.reflect.Type t = getClass().getGenericSuperclass();
        java.lang.reflect.ParameterizedType pt = (java.lang.reflect.ParameterizedType) t;
        this.cl = (Class) pt.getActualTypeArguments()[0];
        this.clName = cl.getSimpleName();
    } 
    
//    private static void execute() throws Exception{
//        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
//        insertEmployee(sessionFactory);
//        //logger.info("AFTER INSERTING -------------------------------");
//        selectEmployees(sessionFactory);
//        getEmployeeCount(sessionFactory);
//         
//        updateEmployee(sessionFactory);
//        ///logger.info("AFTER UPDATING -------------------------------");
//        selectEmployees(sessionFactory);
//         
//        deleteEmployee(sessionFactory);
//        //logger.info("AFTER DELETING -------------------------------");
//        selectEmployees(sessionFactory);
//         
//        sessionFactory.close();               
//    }
      
    private static SessionFactory sessionFactory;   
    
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void setSessionFactory(SessionFactory sessionFactory) {
        TestBasicHibernate.sessionFactory = sessionFactory;
    }
     
    public static <T> void insert(T t) {       
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.save(t);
        session.getTransaction().commit();
        session.close();
    }
 
    public static <T> void select() {
        Session session = sessionFactory.openSession();       
        Criteria criteria = session.createCriteria(cl);       
        List<T> listT = criteria.list();
        if(listT.size() == 0){
            //logger.info("There are no employees in the database");
        } else {
            //logger.info("Listing the employees:");
            for (T t : listT) {
                //logger.info("employee = " + employee);
            }
        }
        session.close();       
    }
 
    public static <T> void getCount() {
        Session session = sessionFactory.openSession();
        Criteria criteria = session.createCriteria(cl);
        criteria.setProjection(Projections.rowCount());         
        Object result = criteria.uniqueResult();
        //logger.info("The count of employees is :" + result );
        session.close();
         
    }
     
    public static <T> void update(String whereColumn,Object whereValue) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Criteria criteria = session.createCriteria(cl);
        criteria.add(Restrictions.eq(whereColumn, whereValue));
        T t = (T)criteria.uniqueResult();
        //t.setName("Abigale");
        session.getTransaction().commit();
        session.close();
    }
 
    public static <T> void delete(String whereColumn,Object whereValue) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();       
        Criteria criteria = session.createCriteria(cl);
        criteria.add(Restrictions.eq(whereColumn, whereValue));
        T t = (T)criteria.uniqueResult();
        session.delete(t);        
        session.getTransaction().commit();
        session.close();
    }
      
}
    

