jooq-with-spring-examples 
=========================
https://github.com/pkainulainen/jooq-with-spring-examples/
http://www.petrikainulainen.net/programming/jooq/using-jooq-with-spring-configuration/
