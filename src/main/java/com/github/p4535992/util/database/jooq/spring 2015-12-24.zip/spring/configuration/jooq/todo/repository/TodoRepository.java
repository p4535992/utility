package com.github.p4535992.util.database.jooq.spring.configuration.jooq.todo.repository;


import com.github.p4535992.util.database.jooq.spring.configuration.jooq.todo.model.Todo;

/**
 * @author Petri Kainulainen
 */
public interface TodoRepository {

    public Todo findById(Long id);

    public void update(Todo updated);

    public void updateAndThrowException(Todo updated);
}
